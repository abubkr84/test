'use strict';

module.exports = function(Tournamentlisting) {

};
