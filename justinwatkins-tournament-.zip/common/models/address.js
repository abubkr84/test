'use strict';

module.exports = function(Address) {

};
