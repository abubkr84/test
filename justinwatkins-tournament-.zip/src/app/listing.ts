export interface Listing {
    id: string;
}
