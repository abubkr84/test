
export interface Filter {
    where?: {any};
    limit?: number;
    skip?: number;

    orderBy: {any}

}
